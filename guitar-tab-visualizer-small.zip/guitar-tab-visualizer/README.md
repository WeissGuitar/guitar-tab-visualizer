# GuitarTab Visualizer Pro

A responsive, embeddable guitar education tool that syncs notation/tab with performance video.

## 🎯 Features

- **Video Player**: HTML5 video with playback controls, speed control, and looping
- **MIDI/XML Uploader**: Drag-and-drop upload for Guitar Pro exports
- **Tab Renderer**: Scrolling tab view with real-time highlighting
- **Fretboard Overlay**: Realistic left-hand simulation on virtual fretboard
- **Embed Wrapper**: WordPress/Elementor safe iframe container

## 🚀 Quick Start

### Prerequisites

1. **Install Node.js** (if not already installed):
   ```bash
   # On macOS with Homebrew
   brew install node
   
   # Or download from https://nodejs.org/
   ```

2. **Verify installation**:
   ```bash
   node --version
   npm --version
   ```

### Installation

1. **Clone or navigate to the project**:
   ```bash
   cd GuitarTabVisualizerPro
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Start development server**:
   ```bash
   npm run dev
   ```

4. **Open in browser**:
   ```
   http://localhost:3000
   ```

## 📁 Project Structure

```
GuitarTabVisualizerPro/
├── components/
│   ├── VideoPlayer.tsx          # Video player with controls
│   ├── MidiXmlUploader.tsx      # File upload component
│   ├── TabRenderer.tsx          # Tab display component
│   ├── FretboardOverlay.tsx     # Fretboard visualization
│   └── EmbedWrapper.tsx         # Iframe wrapper
├── utils/
│   ├── parseMidi.ts             # MIDI file parser
│   └── parseMusicXml.ts         # MusicXML parser
├── pages/
│   ├── index.tsx                # Main test page
│   └── embed/[id].tsx           # Embed page
├── public/
│   ├── test-video.mp4           # Sample video
│   ├── test.mid                 # Sample MIDI
│   └── test.musicxml            # Sample MusicXML
├── styles/
│   └── globals.css              # Global styles
└── package.json                 # Dependencies
```

## 🎵 Supported File Formats

- **MIDI (.mid)**: Standard MIDI files exported from Guitar Pro
- **MusicXML (.musicxml)**: XML-based music notation format
- **Video**: MP4, WebM, OGV (HTML5 video formats)

## 🎸 Component Development

### VideoPlayer.tsx ✅
- ✅ Play/pause controls
- ✅ Speed control (0.5x - 2x)
- ✅ Loop start/end functionality
- ✅ Progress bar with seeking
- ✅ Time display

### MidiXmlUploader.tsx ✅
- ✅ Drag-and-drop file upload
- ✅ MIDI file parsing with Tone.js
- ✅ Note data extraction (pitch, timing, velocity)
- ✅ Tempo and time signature detection
- ✅ Beautiful data display with tables
- ✅ JSON output and console logging

### TabRenderer.tsx ✅
- ✅ MIDI pitch to guitar string/fret mapping
- ✅ Real-time note highlighting with playhead
- ✅ Color-coded notes by pitch class
- ✅ Auto-scrolling to current playback position
- ✅ Multiple test data sets (simple, complex, string test)
- ✅ Responsive design with time markers
- ✅ Note names and fret numbers display

### FretboardOverlay.tsx ✅
- ✅ Horizontal virtual fretboard with 6 strings and 22 frets
- ✅ Realistic fret spacing using the rule of 18
- ✅ Animated finger overlays for active notes
- ✅ Color-coded strings (E2-Red, A2-Orange, D3-Yellow, G3-Green, B3-Blue, E4-Purple)
- ✅ Fret markers at standard positions (3, 5, 7, 9, 12, 15, 17, 19, 21)
- ✅ Upcoming note indicators for anticipation
- ✅ Finger assignment for chord fingerings (1, 2, 3, 4)
- ✅ Velocity-based opacity for dynamic visualization
- ✅ Optional note names overlay

### EmbedWrapper.tsx ✅
- ✅ Complete embeddable wrapper with compact/expanded modes
- ✅ WordPress-ready iframe support with URL parameters
- ✅ Dark/light theme toggle
- ✅ Responsive design for mobile and desktop
- ✅ Auto-resize iframe functionality
- ✅ Lazy loading for performance optimization
- ✅ Customizable footer and branding
- ✅ Multiple embed instances support

## 🎉 **PROJECT COMPLETE!**

### 🚀 **Ready for Launch:**
- ✅ **Full visualizer engine** with all components
- ✅ **Fully embeddable** and scalable product
- ✅ **WordPress integration** ready
- ✅ **Legal and clean** MIDI-based input system
- ✅ **Professional documentation** and embed instructions

### 📋 **What's Included:**
1. **VideoPlayer.tsx** - Full-featured video player with controls
2. **MidiXmlUploader.tsx** - Drag-and-drop MIDI file parsing
3. **TabRenderer.tsx** - Real-time guitar tab visualization
4. **FretboardOverlay.tsx** - Virtual fretboard with animated hand
5. **EmbedWrapper.tsx** - Complete embeddable product wrapper
6. **Embed Instructions** - Comprehensive WordPress integration guide

### 🎯 **Next Steps:**
1. **Deploy to Vercel** for live testing
2. **Add custom domain** for production
3. **Create sample content** for demonstrations
4. **Market to guitar educators** and course creators

## 🛠️ Development

### Available Scripts

```bash
npm run dev      # Start development server
npm run build    # Build for production
npm run start    # Start production server
npm run lint     # Run ESLint
```

### Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS
- **Video**: HTML5 `<video>` element
- **Parsing**: `@tonejs/midi`, `musicxml-interfaces`
- **Framework**: Next.js 14

## 🎯 Usage Examples

### Basic Video Player
```tsx
import VideoPlayer from '../components/VideoPlayer';

<VideoPlayer
  src="/path/to/video.mp4"
  onTimeUpdate={(time) => console.log('Current time:', time)}
  onDurationChange={(duration) => console.log('Duration:', duration)}
/>
```

### With Looping
```tsx
<VideoPlayer
  src="/path/to/video.mp4"
  loopStart={10}
  loopEnd={30}
  isLooping={true}
  onLoopToggle={(looping) => setLooping(looping)}
/>
```

## 🔧 Configuration

### Tailwind CSS
Custom guitar-themed colors are available:
- `bg-guitar-primary` - Dark background
- `bg-guitar-secondary` - Secondary background
- `text-guitar-accent` - Orange accent color
- `bg-guitar-fret` - Fret color
- `bg-guitar-string` - String color

### Environment Variables
Create a `.env.local` file for any API keys or configuration:
```env
NEXT_PUBLIC_API_URL=your_api_url
```

## 📱 Responsive Design

The components are built with mobile-first responsive design:
- **Mobile**: Compact controls, touch-friendly
- **Tablet**: Balanced layout
- **Desktop**: Full feature set with hover states

## 🚀 Deployment

### Vercel (Recommended)
1. Push to GitHub
2. Connect to Vercel
3. Deploy automatically

### Other Platforms
```bash
npm run build
npm run start
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

MIT License - see LICENSE file for details

## 🎸 About

Built for guitar education and practice. Perfect for:
- Online guitar lessons
- Practice video synchronization
- Tab display and learning
- Technique visualization

---

**Next Step**: Install Node.js and run `npm install` to get started! 