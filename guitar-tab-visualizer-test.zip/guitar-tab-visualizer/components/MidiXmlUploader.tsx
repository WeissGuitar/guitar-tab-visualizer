'use client';

import React, { useState, useRef, useCallback } from 'react';
import * as Tone from 'tone';

interface NoteEvent {
  pitch: number;
  startTime: number;
  duration: number;
  velocity: number;
  channel: number;
}

interface ParsedMidiData {
  notes: NoteEvent[];
  duration: number;
  tempo: number;
  timeSignature: [number, number];
}

const MidiXmlUploader: React.FC = () => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [parsedData, setParsedData] = useState<ParsedMidiData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const parseMidiFile = async (file: File): Promise<ParsedMidiData> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = async (e) => {
        try {
          const arrayBuffer = e.target?.result as ArrayBuffer;
          if (!arrayBuffer) {
            throw new Error('Failed to read file');
          }

          // Use Tone.js Midi parser
          const midi = await Tone.Midi.fromArrayBuffer(arrayBuffer);
          
          const notes: NoteEvent[] = [];
          let totalDuration = 0;
          let tempo = 120; // Default tempo
          let timeSignature: [number, number] = [4, 4]; // Default time signature

          // Extract tempo and time signature from first track
          if (midi.tracks.length > 0) {
            const firstTrack = midi.tracks[0];
            
            // Find tempo
            const tempoEvent = firstTrack.notes.find(note => 
              note.type === 'tempo' || note.time && note.time > 0
            );
            if (tempoEvent && 'tempo' in tempoEvent) {
              tempo = (tempoEvent as any).tempo || 120;
            }

            // Find time signature
            const timeSigEvent = firstTrack.notes.find(note => 
              note.type === 'timeSignature'
            );
            if (timeSigEvent && 'timeSignature' in timeSigEvent) {
              const ts = (timeSigEvent as any).timeSignature;
              timeSignature = [ts[0], ts[1]];
            }
          }

          // Parse notes from all tracks
          midi.tracks.forEach((track, trackIndex) => {
            track.notes.forEach((note) => {
              if (note.type === 'note') {
                notes.push({
                  pitch: note.midi,
                  startTime: note.time,
                  duration: note.duration,
                  velocity: note.velocity,
                  channel: trackIndex
                });
                
                // Update total duration
                const noteEndTime = note.time + note.duration;
                if (noteEndTime > totalDuration) {
                  totalDuration = noteEndTime;
                }
              }
            });
          });

          // Sort notes by start time
          notes.sort((a, b) => a.startTime - b.startTime);

          resolve({
            notes,
            duration: totalDuration,
            tempo,
            timeSignature
          });

        } catch (err) {
          reject(err);
        }
      };

      reader.onerror = () => reject(new Error('Failed to read file'));
      reader.readAsArrayBuffer(file);
    });
  };

  const handleFile = async (file: File) => {
    setIsLoading(true);
    setError(null);
    setParsedData(null);
    setFileName(file.name);

    try {
      // Check file type
      const fileExtension = file.name.toLowerCase().split('.').pop();
      if (fileExtension !== 'mid' && fileExtension !== 'midi') {
        throw new Error('Please upload a MIDI file (.mid or .midi)');
      }

      const data = await parseMidiFile(file);
      setParsedData(data);
      
      // Log to console for debugging
      console.log('Parsed MIDI Data:', data);
      console.log('Notes:', data.notes);
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to parse file');
      console.error('Error parsing MIDI file:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  }, []);

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getNoteName = (pitch: number) => {
    const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const octave = Math.floor(pitch / 12) - 1;
    const noteName = noteNames[pitch % 12];
    return `${noteName}${octave}`;
  };

  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Upload Area */}
      <div
        className={`relative border-2 border-dashed rounded-lg p-8 text-center transition-all duration-200 ${
          isDragOver
            ? 'border-guitar-accent bg-guitar-accent/10'
            : 'border-gray-600 hover:border-gray-500'
        } ${isLoading ? 'opacity-50 pointer-events-none' : ''}`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".mid,.midi"
          onChange={handleFileInput}
          className="hidden"
        />
        
        <div className="space-y-4">
          <div className="text-6xl">🎵</div>
          <h3 className="text-xl font-semibold text-white">
            {isLoading ? 'Processing...' : 'Upload MIDI File'}
          </h3>
          <p className="text-gray-400">
            Drag and drop a .mid or .midi file here, or click to browse
          </p>
          <div className="text-sm text-gray-500">
            Supports Guitar Pro exports and standard MIDI files
          </div>
        </div>

        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 rounded-lg">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-guitar-accent"></div>
          </div>
        )}
      </div>

      {/* Error Display */}
      {error && (
        <div className="mt-4 p-4 bg-red-900/20 border border-red-500 rounded-lg">
          <div className="flex items-center space-x-2">
            <span className="text-red-400">⚠️</span>
            <span className="text-red-300">{error}</span>
          </div>
        </div>
      )}

      {/* File Info */}
      {fileName && !error && (
        <div className="mt-4 p-4 bg-guitar-secondary rounded-lg">
          <div className="flex items-center space-x-2">
            <span className="text-green-400">✅</span>
            <span className="text-white font-medium">{fileName}</span>
          </div>
        </div>
      )}

      {/* Parsed Data Display */}
      {parsedData && (
        <div className="mt-6 space-y-4">
          {/* Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="bg-guitar-secondary p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-400 mb-1">Total Notes</h4>
              <p className="text-2xl font-bold text-guitar-accent">{parsedData.notes.length}</p>
            </div>
            <div className="bg-guitar-secondary p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-400 mb-1">Duration</h4>
              <p className="text-2xl font-bold text-guitar-accent">{formatTime(parsedData.duration)}</p>
            </div>
            <div className="bg-guitar-secondary p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-400 mb-1">Tempo</h4>
              <p className="text-2xl font-bold text-guitar-accent">{parsedData.tempo} BPM</p>
            </div>
            <div className="bg-guitar-secondary p-4 rounded-lg">
              <h4 className="text-sm font-medium text-gray-400 mb-1">Time Signature</h4>
              <p className="text-2xl font-bold text-guitar-accent">{parsedData.timeSignature[0]}/{parsedData.timeSignature[1]}</p>
            </div>
          </div>

          {/* Notes List */}
          <div className="bg-guitar-secondary rounded-lg overflow-hidden">
            <div className="p-4 border-b border-gray-700">
              <h3 className="text-lg font-semibold text-white">Parsed Notes</h3>
              <p className="text-sm text-gray-400">Showing first 20 notes</p>
            </div>
            <div className="max-h-96 overflow-y-auto">
              <table className="w-full">
                <thead className="bg-guitar-primary">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Note</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Pitch</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Start Time</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Duration</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Velocity</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-400 uppercase tracking-wider">Channel</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {parsedData.notes.slice(0, 20).map((note, index) => (
                    <tr key={index} className="hover:bg-guitar-primary/50">
                      <td className="px-4 py-2 text-sm text-white font-mono">
                        {getNoteName(note.pitch)}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-300">
                        {note.pitch}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-300">
                        {note.startTime.toFixed(2)}s
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-300">
                        {note.duration.toFixed(2)}s
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-300">
                        {note.velocity}
                      </td>
                      <td className="px-4 py-2 text-sm text-gray-300">
                        {note.channel}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {parsedData.notes.length > 20 && (
                <div className="p-4 text-center text-sm text-gray-400">
                  ... and {parsedData.notes.length - 20} more notes
                </div>
              )}
            </div>
          </div>

          {/* JSON Output */}
          <div className="bg-guitar-secondary rounded-lg overflow-hidden">
            <div className="p-4 border-b border-gray-700">
              <h3 className="text-lg font-semibold text-white">JSON Output</h3>
              <p className="text-sm text-gray-400">Parsed data structure (check console for full output)</p>
            </div>
            <div className="p-4">
              <pre className="text-xs text-gray-300 overflow-x-auto">
                {JSON.stringify({
                  noteCount: parsedData.notes.length,
                  duration: parsedData.duration,
                  tempo: parsedData.tempo,
                  timeSignature: parsedData.timeSignature,
                  sampleNotes: parsedData.notes.slice(0, 3)
                }, null, 2)}
              </pre>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MidiXmlUploader; 