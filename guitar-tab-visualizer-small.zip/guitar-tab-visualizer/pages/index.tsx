import React, { useState, useEffect } from 'react';
import VideoPlayer from '../components/VideoPlayer';
import MidiXmlUploader from '../components/MidiXmlUploader';
import TabRenderer from '../components/TabRenderer';
import FretboardOverlay from '../components/FretboardOverlay';
import EmbedWrapper from '../components/EmbedWrapper';
import { downloadTestMidi } from '../utils/createTestMidi';
import { createTestTabData, createComplexTestData, createStringTestData } from '../utils/createTestTabData';

export default function Home() {
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isLooping, setIsLooping] = useState(false);
  const [loopStart, setLoopStart] = useState(0);
  const [loopEnd, setLoopEnd] = useState(0);
  const [tabNotes, setTabNotes] = useState(createTestTabData());
  const [tabTestType, setTabTestType] = useState<'simple' | 'complex' | 'strings'>('simple');

  const handleTimeUpdate = (time: number) => {
    setCurrentTime(time);
  };

  const handleDurationChange = (dur: number) => {
    setDuration(dur);
    // Set default loop end to 80% of duration
    setLoopEnd(dur * 0.8);
  };

  const handleLoopToggle = (looping: boolean) => {
    setIsLooping(looping);
  };

  // Update tab notes when test type changes
  useEffect(() => {
    switch (tabTestType) {
      case 'simple':
        setTabNotes(createTestTabData());
        break;
      case 'complex':
        setTabNotes(createComplexTestData());
        break;
      case 'strings':
        setTabNotes(createStringTestData());
        break;
    }
  }, [tabTestType]);

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-8">
          <h1 className="text-4xl font-bold text-guitar-accent mb-2">
            GuitarTab Visualizer Pro
          </h1>
          <p className="text-gray-300">
            A responsive, embeddable guitar education tool
          </p>
        </header>

        <div className="max-w-4xl mx-auto">
          {/* Video Player Section */}
          <div className="mb-8">
            <h2 className="text-2xl font-semibold mb-4">Video Player Test</h2>
            <VideoPlayer
              src="/test-video.mp4"
              onTimeUpdate={handleTimeUpdate}
              onDurationChange={handleDurationChange}
              loopStart={loopStart}
              loopEnd={loopEnd}
              isLooping={isLooping}
              onLoopToggle={handleLoopToggle}
            />
          </div>

          {/* Status Display */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-guitar-secondary p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Current Time</h3>
              <p className="text-2xl text-guitar-accent">
                {Math.floor(currentTime / 60)}:{(currentTime % 60).toFixed(1).padStart(4, '0')}
              </p>
            </div>
            <div className="bg-guitar-secondary p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Duration</h3>
              <p className="text-2xl text-guitar-accent">
                {Math.floor(duration / 60)}:{(duration % 60).toFixed(1).padStart(4, '0')}
              </p>
            </div>
            <div className="bg-guitar-secondary p-4 rounded-lg">
              <h3 className="text-lg font-semibold mb-2">Loop Status</h3>
              <p className="text-2xl text-guitar-accent">
                {isLooping ? 'Active' : 'Inactive'}
              </p>
            </div>
          </div>

          {/* Loop Controls */}
          <div className="bg-guitar-secondary p-6 rounded-lg mb-8">
            <h3 className="text-xl font-semibold mb-4">Loop Controls</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Loop Start (seconds)</label>
                <input
                  type="number"
                  value={loopStart}
                  onChange={(e) => setLoopStart(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-guitar-primary border border-gray-600 rounded-lg text-white"
                  min="0"
                  max={duration}
                  step="0.1"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Loop End (seconds)</label>
                <input
                  type="number"
                  value={loopEnd}
                  onChange={(e) => setLoopEnd(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-2 bg-guitar-primary border border-gray-600 rounded-lg text-white"
                  min="0"
                  max={duration}
                  step="0.1"
                />
              </div>
            </div>
          </div>

          {/* MIDI Uploader Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">MIDI File Uploader</h2>
              <button
                onClick={downloadTestMidi}
                className="px-4 py-2 bg-guitar-accent hover:bg-orange-500 text-white rounded-lg transition-colors text-sm"
              >
                Generate Test MIDI
              </button>
            </div>
            <MidiXmlUploader />
          </div>

          {/* Tab Renderer Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Tab Renderer</h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => setTabTestType('simple')}
                  className={`px-3 py-1 rounded text-sm transition-colors ${
                    tabTestType === 'simple'
                      ? 'bg-guitar-accent text-white'
                      : 'bg-guitar-secondary text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  Simple
                </button>
                <button
                  onClick={() => setTabTestType('complex')}
                  className={`px-3 py-1 rounded text-sm transition-colors ${
                    tabTestType === 'complex'
                      ? 'bg-guitar-accent text-white'
                      : 'bg-guitar-secondary text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  Complex
                </button>
                <button
                  onClick={() => setTabTestType('strings')}
                  className={`px-3 py-1 rounded text-sm transition-colors ${
                    tabTestType === 'strings'
                      ? 'bg-guitar-accent text-white'
                      : 'bg-guitar-secondary text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  Strings
                </button>
              </div>
            </div>
            <TabRenderer
              notes={tabNotes}
              currentTime={currentTime}
              width={800}
              height={300}
              showNoteNames={true}
              colorByPitch={true}
            />
          </div>

          {/* Fretboard Overlay Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Virtual Fretboard</h2>
              <div className="flex space-x-2">
                <button
                  onClick={() => setTabTestType('simple')}
                  className={`px-3 py-1 rounded text-sm transition-colors ${
                    tabTestType === 'simple'
                      ? 'bg-guitar-accent text-white'
                      : 'bg-guitar-secondary text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  Simple
                </button>
                <button
                  onClick={() => setTabTestType('complex')}
                  className={`px-3 py-1 rounded text-sm transition-colors ${
                    tabTestType === 'complex'
                      ? 'bg-guitar-accent text-white'
                      : 'bg-guitar-secondary text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  Complex
                </button>
                <button
                  onClick={() => setTabTestType('strings')}
                  className={`px-3 py-1 rounded text-sm transition-colors ${
                    tabTestType === 'strings'
                      ? 'bg-guitar-accent text-white'
                      : 'bg-guitar-secondary text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  Strings
                </button>
              </div>
            </div>
            <FretboardOverlay
              notes={tabNotes}
              currentTime={currentTime}
              width={800}
              height={200}
              showFingerNames={true}
              showNoteNames={false}
            />
          </div>

          {/* Embed Wrapper Section */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold">Embed Wrapper (Complete Product)</h2>
              <div className="flex space-x-2">
                <a
                  href="/embed/test?theme=dark&expanded=true"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-guitar-accent hover:bg-orange-500 text-white rounded-lg transition-colors text-sm"
                >
                  Open Embed
                </a>
              </div>
            </div>
            <div className="border-2 border-dashed border-gray-600 rounded-lg p-4">
              <EmbedWrapper
                embedId="demo"
                compactOnly={false}
                defaultExpanded={false}
                videoSrc="/test-video.mp4"
                midiData={tabNotes}
                theme="dark"
                showFooter={true}
              />
            </div>
          </div>

          {/* Features Preview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-guitar-secondary p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">🎵 MIDI/XML Uploader</h3>
              <p className="text-gray-300 mb-4">
                Drag-and-drop upload for MIDI or MusicXML files exported from Guitar Pro
              </p>
              <div className="text-sm text-gray-400">
                • Supports .mid and .musicxml formats<br/>
                • Parses note data and timing<br/>
                • Extracts string/fret information
              </div>
            </div>

            <div className="bg-guitar-secondary p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">🎸 Tab Renderer</h3>
              <p className="text-gray-300 mb-4">
                Renders parsed note data in scrolling tab-style view with highlighting
              </p>
              <div className="text-sm text-gray-400">
                • Real-time note highlighting<br/>
                • Scrolls with video playback<br/>
                • Multiple viewing modes
              </div>
            </div>

            <div className="bg-guitar-secondary p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">🎯 Fretboard Overlay</h3>
              <p className="text-gray-300 mb-4">
                Realistic left-hand simulation pressing frets on virtual fretboard
              </p>
              <div className="text-sm text-gray-400">
                • 6-string, 12-20 fret display<br/>
                • Animated finger movements<br/>
                • Visual feedback for technique
              </div>
            </div>

            <div className="bg-guitar-secondary p-6 rounded-lg">
              <h3 className="text-xl font-semibold mb-4">📱 Embed Wrapper</h3>
              <p className="text-gray-300 mb-4">
                Resizable iframe container with Compact and Expanded viewing modes
              </p>
              <div className="text-sm text-gray-400">
                • WordPress/Elementor safe<br/>
                • Mobile responsive<br/>
                • Customizable sizing
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
} 