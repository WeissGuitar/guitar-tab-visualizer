import { useRouter } from 'next/router';
import { GetServerSideProps } from 'next';
import EmbedWrapper from '../../components/EmbedWrapper';
import { createTestTabData } from '../../utils/createTestTabData';

interface EmbedPageProps {
  embedId: string;
  theme: 'dark' | 'light';
  compactOnly: boolean;
  defaultExpanded: boolean;
  videoSrc: string;
  showFooter: boolean;
}

export default function EmbedPage({
  embedId,
  theme,
  compactOnly,
  defaultExpanded,
  videoSrc,
  showFooter,
}: EmbedPageProps) {
  return (
    <EmbedWrapper
      embedId={embedId}
      theme={theme}
      compactOnly={compactOnly}
      defaultExpanded={defaultExpanded}
      videoSrc={videoSrc}
      midiData={createTestTabData()} // Default test data
      showFooter={showFooter}
    />
  );
}

export const getServerSideProps: GetServerSideProps = async (context) => {
  const { id, theme, compact, expanded, video, footer } = context.query;

  return {
    props: {
      embedId: id || 'default',
      theme: (theme as 'dark' | 'light') || 'dark',
      compactOnly: compact === 'true',
      defaultExpanded: expanded === 'true',
      videoSrc: (video as string) || '/test-video.mp4',
      showFooter: footer !== 'false',
    },
  };
}; 