export default function Home() {
  return (
    <div>
      <h1>GuitarTab Visualizer Pro</h1>
      <p>🎸 Your guitar education tool is working!</p>
      <a href="/embed/default">View Embed Version</a>
    </div>
  );
} 