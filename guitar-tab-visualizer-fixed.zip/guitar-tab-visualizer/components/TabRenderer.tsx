'use client';

import React, { useMemo, useRef, useEffect } from 'react';

interface NoteEvent {
  pitch: number;
  startTime: number;
  duration: number;
  velocity: number;
  channel?: number;
}

interface TabNote {
  stringIndex: number;
  fretNumber: number;
  startTime: number;
  duration: number;
  velocity: number;
  pitch: number;
  noteName: string;
}

interface TabRendererProps {
  notes: NoteEvent[];
  currentTime: number;
  width?: number;
  height?: number;
  showNoteNames?: boolean;
  colorByPitch?: boolean;
}

const TabRenderer: React.FC<TabRendererProps> = ({
  notes,
  currentTime,
  width = 800,
  height = 300,
  showNoteNames = false,
  colorByPitch = true,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Standard guitar tuning (E2, A2, D3, G3, B3, E4)
  const stringTunings = [40, 45, 50, 55, 59, 64]; // MIDI note numbers
  const stringNames = ['E2', 'A2', 'D3', 'G3', 'B3', 'E4'];

  // Pitch class colors for color coding
  const pitchColors = {
    0: 'bg-red-500',   // C
    1: 'bg-red-600',   // C#
    2: 'bg-orange-500', // D
    3: 'bg-orange-600', // D#
    4: 'bg-yellow-500', // E
    5: 'bg-green-500',  // F
    6: 'bg-green-600',  // F#
    7: 'bg-blue-500',   // G
    8: 'bg-blue-600',   // G#
    9: 'bg-purple-500', // A
    10: 'bg-purple-600', // A#
    11: 'bg-pink-500',  // B
  };

  // Convert MIDI pitch to string/fret combination
  const pitchToFret = (pitch: number): { stringIndex: number; fretNumber: number } => {
    // Find the lowest possible fret for this pitch
    for (let stringIndex = 5; stringIndex >= 0; stringIndex--) {
      const stringPitch = stringTunings[stringIndex];
      const fretNumber = pitch - stringPitch;
      
      if (fretNumber >= 0 && fretNumber <= 24) { // Reasonable fret range
        return { stringIndex, fretNumber };
      }
    }
    
    // Fallback: use the highest string
    return { stringIndex: 0, fretNumber: pitch - stringTunings[0] };
  };

  // Get note name from pitch
  const getNoteName = (pitch: number): string => {
    const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const octave = Math.floor(pitch / 12) - 1;
    const noteName = noteNames[pitch % 12];
    return `${noteName}${octave}`;
  };

  // Convert notes to tab format
  const tabNotes = useMemo(() => {
    return notes.map(note => {
      const { stringIndex, fretNumber } = pitchToFret(note.pitch);
      return {
        ...note,
        stringIndex,
        fretNumber,
        noteName: getNoteName(note.pitch),
      } as TabNote;
    }).sort((a, b) => a.startTime - b.startTime);
  }, [notes]);

  // Calculate total duration and time scale
  const totalDuration = useMemo(() => {
    if (tabNotes.length === 0) return 10;
    const lastNote = tabNotes[tabNotes.length - 1];
    return Math.max(lastNote.startTime + lastNote.duration, 10);
  }, [tabNotes]);

  const timeScale = width / totalDuration; // pixels per second

  // Auto-scroll to current time
  useEffect(() => {
    if (scrollRef.current && currentTime > 0) {
      const scrollPosition = currentTime * timeScale - width / 2;
      scrollRef.current.scrollLeft = Math.max(0, scrollPosition);
    }
  }, [currentTime, timeScale, width]);

  // Get color for a note
  const getNoteColor = (pitch: number, velocity: number): string => {
    if (!colorByPitch) {
      return 'bg-guitar-accent';
    }
    
    const pitchClass = pitch % 12;
    const baseColor = pitchColors[pitchClass as keyof typeof pitchColors] || 'bg-gray-500';
    const intensity = Math.min(velocity / 127, 1);
    
    // Adjust opacity based on velocity
    return `${baseColor} opacity-${Math.max(60, Math.floor(intensity * 100))}`;
  };

  // Check if note is currently playing
  const isNotePlaying = (note: TabNote): boolean => {
    return currentTime >= note.startTime && currentTime <= note.startTime + note.duration;
  };

  // Check if note is in the future
  const isNoteFuture = (note: TabNote): boolean => {
    return currentTime < note.startTime;
  };

  // Check if note is in the past
  const isNotePast = (note: TabNote): boolean => {
    return currentTime > note.startTime + note.duration;
  };

  return (
    <div className="w-full bg-guitar-primary rounded-lg overflow-hidden" style={{ height }}>
      {/* Header with time markers */}
      <div className="bg-guitar-secondary px-4 py-2 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-semibold">Guitar Tab</h3>
          <div className="text-sm text-gray-400">
            Current Time: {currentTime.toFixed(2)}s / {totalDuration.toFixed(2)}s
          </div>
        </div>
      </div>

      {/* Tab Display */}
      <div 
        ref={containerRef}
        className="relative overflow-x-auto overflow-y-hidden"
        style={{ height: height - 60 }}
      >
        <div 
          ref={scrollRef}
          className="relative"
          style={{ width: Math.max(width, totalDuration * timeScale) }}
        >
          {/* Time markers */}
          <div className="absolute top-0 left-0 right-0 h-6 bg-guitar-secondary/50 flex items-center text-xs text-gray-400">
            {Array.from({ length: Math.ceil(totalDuration) + 1 }, (_, i) => (
              <div
                key={i}
                className="absolute border-l border-gray-600 px-1"
                style={{ left: i * timeScale }}
              >
                {i}s
              </div>
            ))}
          </div>

          {/* String lines */}
          <div className="mt-6">
            {stringNames.map((stringName, stringIndex) => (
              <div
                key={stringIndex}
                className="relative flex items-center border-b border-gray-600"
                style={{ height: (height - 60) / 6 }}
              >
                {/* String name */}
                <div className="absolute left-0 w-12 h-full bg-guitar-secondary flex items-center justify-center text-xs text-gray-300 font-mono z-10">
                  {stringName}
                </div>

                {/* String line */}
                <div 
                  className="absolute left-12 right-0 h-px bg-guitar-string"
                  style={{ top: '50%', transform: 'translateY(-50%)' }}
                />

                {/* Notes on this string */}
                {tabNotes
                  .filter(note => note.stringIndex === stringIndex)
                  .map((note, noteIndex) => {
                    const left = note.startTime * timeScale + 48; // 48px for string name
                    const noteWidth = Math.max(note.duration * timeScale, 20);
                    const isPlaying = isNotePlaying(note);
                    const isFuture = isNoteFuture(note);
                    const isPast = isNotePast(note);

                    return (
                      <div
                        key={`${stringIndex}-${noteIndex}`}
                        className={`absolute rounded-lg flex items-center justify-center text-xs font-bold transition-all duration-200 ${
                          isPlaying
                            ? 'ring-2 ring-yellow-400 ring-opacity-75 scale-110'
                            : isFuture
                            ? 'opacity-60'
                            : isPast
                            ? 'opacity-40'
                            : ''
                        } ${getNoteColor(note.pitch, note.velocity)}`}
                        style={{
                          left,
                          width: noteWidth,
                          height: 24,
                          top: '50%',
                          transform: 'translateY(-50%)',
                        }}
                        title={`${note.noteName} - Fret ${note.fretNumber} - ${note.startTime.toFixed(2)}s`}
                      >
                        <span className="text-white drop-shadow-sm">
                          {note.fretNumber}
                        </span>
                        {showNoteNames && (
                          <span className="absolute -top-6 left-1/2 transform -translate-x-1/2 text-xs text-gray-300">
                            {note.noteName}
                          </span>
                        )}
                      </div>
                    );
                  })}
              </div>
            ))}
          </div>

          {/* Playhead indicator */}
          {currentTime > 0 && (
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-yellow-400 z-20"
              style={{ left: currentTime * timeScale + 48 }}
            >
              <div className="absolute -top-1 -left-1 w-3 h-3 bg-yellow-400 rounded-full animate-pulse" />
            </div>
          )}
        </div>
      </div>

      {/* Legend */}
      <div className="bg-guitar-secondary px-4 py-2 border-t border-gray-700">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse" />
              <span>Currently Playing</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-guitar-accent rounded" />
              <span>Notes</span>
            </div>
          </div>
          <div className="text-right">
            <div>Total Notes: {tabNotes.length}</div>
            <div>Duration: {totalDuration.toFixed(1)}s</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TabRenderer; 