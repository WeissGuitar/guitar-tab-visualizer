# GuitarTab Visualizer Pro - Embed Instructions

## 🚀 Quick Start

### Basic Embed
```html
<iframe 
  src="https://your-domain.com/embed/default" 
  width="100%" 
  height="600" 
  frameborder="0"
  allowfullscreen>
</iframe>
```

### Advanced Embed with Parameters
```html
<iframe 
  src="https://your-domain.com/embed/my-lesson?theme=dark&expanded=true&video=https://example.com/video.mp4&footer=false" 
  width="100%" 
  height="800" 
  frameborder="0"
  allowfullscreen>
</iframe>
```

## 📋 URL Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `id` | string | `default` | Unique embed identifier |
| `theme` | `dark` \| `light` | `dark` | Color theme |
| `compact` | `true` \| `false` | `false` | Compact mode only |
| `expanded` | `true` \| `false` | `false` | Start in expanded mode |
| `video` | URL | `/test-video.mp4` | Video source URL |
| `footer` | `true` \| `false` | `true` | Show footer branding |

## 🎯 WordPress Integration

### Method 1: Elementor HTML Widget
1. Add an HTML widget to your page
2. Paste the iframe code above
3. Adjust width/height as needed

### Method 2: WPCode Plugin
1. Install WPCode plugin
2. Create new snippet with iframe code
3. Set location to "Insert After Content" or "Insert Before Content"

### Method 3: Custom Shortcode
Add this to your `functions.php`:
```php
function guitar_tab_embed_shortcode($atts) {
    $atts = shortcode_atts(array(
        'id' => 'default',
        'theme' => 'dark',
        'compact' => 'false',
        'expanded' => 'false',
        'video' => '/test-video.mp4',
        'footer' => 'true',
        'width' => '100%',
        'height' => '600'
    ), $atts);
    
    $url = "https://your-domain.com/embed/{$atts['id']}?theme={$atts['theme']}&compact={$atts['compact']}&expanded={$atts['expanded']}&video={$atts['video']}&footer={$atts['footer']}";
    
    return "<iframe src='{$url}' width='{$atts['width']}' height='{$atts['height']}' frameborder='0' allowfullscreen></iframe>";
}
add_shortcode('guitar_tab', 'guitar_tab_embed_shortcode');
```

Then use: `[guitar_tab id="lesson-1" theme="dark" expanded="true"]`

## 📱 Responsive Design

### Mobile-Friendly Embed
```html
<div style="position: relative; padding-bottom: 56.25%; height: 0; overflow: hidden;">
  <iframe 
    src="https://your-domain.com/embed/default" 
    style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;"
    frameborder="0"
    allowfullscreen>
  </iframe>
</div>
```

### Auto-Resize iframe
The embed automatically resizes based on content. For dynamic height:
```html
<iframe 
  id="guitar-tab-embed"
  src="https://your-domain.com/embed/default" 
  width="100%" 
  height="600" 
  frameborder="0"
  allowfullscreen>
</iframe>

<script>
window.addEventListener('message', function(event) {
  if (event.data.type === 'resize') {
    document.getElementById('guitar-tab-embed').style.height = event.data.height + 'px';
  }
});
</script>
```

## 🎨 Customization Examples

### Compact Mode for Blog Posts
```html
<iframe 
  src="https://your-domain.com/embed/lesson-1?compact=true&theme=light&footer=false" 
  width="100%" 
  height="400" 
  frameborder="0">
</iframe>
```

### Full-Featured Mode for Course Pages
```html
<iframe 
  src="https://your-domain.com/embed/advanced-lesson?expanded=true&theme=dark&video=https://example.com/lesson-video.mp4" 
  width="100%" 
  height="800" 
  frameborder="0"
  allowfullscreen>
</iframe>
```

### Light Theme for Light Websites
```html
<iframe 
  src="https://your-domain.com/embed/lesson-2?theme=light&expanded=true" 
  width="100%" 
  height="700" 
  frameborder="0">
</iframe>
```

## 🔧 Advanced Features

### Multiple Embeds on Same Page
Each embed needs a unique ID:
```html
<!-- First embed -->
<iframe src="https://your-domain.com/embed/lesson-1" width="100%" height="600"></iframe>

<!-- Second embed -->
<iframe src="https://your-domain.com/embed/lesson-2" width="100%" height="600"></iframe>
```

### Custom Video Sources
```html
<iframe 
  src="https://your-domain.com/embed/custom?video=https://your-cdn.com/guitar-lesson.mp4" 
  width="100%" 
  height="600">
</iframe>
```

## 🚀 Deployment

### Vercel Deployment
1. Push code to GitHub
2. Connect to Vercel
3. Deploy automatically
4. Update embed URLs to your Vercel domain

### Custom Domain
1. Add custom domain in Vercel
2. Update all embed URLs
3. Test all parameters

## 📊 Analytics & Tracking

### Google Analytics
Add tracking to your embeds:
```html
<iframe 
  src="https://your-domain.com/embed/lesson-1?utm_source=blog&utm_medium=embed&utm_campaign=guitar-lessons" 
  width="100%" 
  height="600">
</iframe>
```

## 🛠️ Troubleshooting

### Common Issues

1. **iframe not loading**
   - Check if the embed URL is accessible
   - Verify CORS settings
   - Check browser console for errors

2. **Video not playing**
   - Ensure video URL is accessible
   - Check video format (MP4 recommended)
   - Verify CORS for external videos

3. **Responsive issues**
   - Use the responsive wrapper code above
   - Test on different screen sizes
   - Check iframe height settings

### Support
For technical support, contact: support@your-domain.com

## 📄 License
GuitarTab Visualizer Pro - MIT License 