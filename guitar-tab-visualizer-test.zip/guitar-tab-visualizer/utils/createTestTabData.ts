// Test data for TabRenderer component
// Creates sample MIDI notes that will display as guitar tab

export interface NoteEvent {
  pitch: number;
  startTime: number;
  duration: number;
  velocity: number;
  channel?: number;
}

export const createTestTabData = (): NoteEvent[] => {
  // Create a simple C major scale pattern
  const cMajorScale = [60, 62, 64, 65, 67, 69, 71, 72]; // C4 to C5
  const notes: NoteEvent[] = [];

  // Add ascending scale
  cMajorScale.forEach((pitch, index) => {
    notes.push({
      pitch,
      startTime: index * 0.5,
      duration: 0.4,
      velocity: 100,
      channel: 0
    });
  });

  // Add some chords
  notes.push(
    { pitch: 60, startTime: 4.0, duration: 1.0, velocity: 100, channel: 0 }, // C
    { pitch: 64, startTime: 4.0, duration: 1.0, velocity: 100, channel: 0 }, // E
    { pitch: 67, startTime: 4.0, duration: 1.0, velocity: 100, channel: 0 }, // G
    { pitch: 62, startTime: 5.5, duration: 1.0, velocity: 100, channel: 0 }, // D
    { pitch: 65, startTime: 5.5, duration: 1.0, velocity: 100, channel: 0 }, // F
    { pitch: 69, startTime: 5.5, duration: 1.0, velocity: 100, channel: 0 }, // A
  );

  // Add some bass notes
  notes.push(
    { pitch: 48, startTime: 7.0, duration: 0.5, velocity: 80, channel: 0 },  // C3
    { pitch: 50, startTime: 7.5, duration: 0.5, velocity: 80, channel: 0 },  // D3
    { pitch: 52, startTime: 8.0, duration: 0.5, velocity: 80, channel: 0 },  // E3
    { pitch: 53, startTime: 8.5, duration: 0.5, velocity: 80, channel: 0 },  // F3
  );

  // Add some higher notes for variety
  notes.push(
    { pitch: 72, startTime: 9.0, duration: 0.3, velocity: 90, channel: 0 },  // C5
    { pitch: 74, startTime: 9.3, duration: 0.3, velocity: 90, channel: 0 },  // D5
    { pitch: 76, startTime: 9.6, duration: 0.3, velocity: 90, channel: 0 },  // E5
    { pitch: 77, startTime: 9.9, duration: 0.3, velocity: 90, channel: 0 },  // F5
  );

  return notes.sort((a, b) => a.startTime - b.startTime);
};

// Create more complex test data with different velocities and timing
export const createComplexTestData = (): NoteEvent[] => {
  const notes: NoteEvent[] = [];
  
  // Arpeggio pattern
  const arpeggioNotes = [60, 64, 67, 72]; // C major arpeggio
  arpeggioNotes.forEach((pitch, index) => {
    notes.push({
      pitch,
      startTime: index * 0.25,
      duration: 0.2,
      velocity: 100 - (index * 10),
      channel: 0
    });
  });

  // Melodic line
  const melody = [67, 69, 71, 72, 71, 69, 67, 65]; // G A B C B A G F
  melody.forEach((pitch, index) => {
    notes.push({
      pitch,
      startTime: 2.0 + (index * 0.3),
      duration: 0.25,
      velocity: 90 + (index % 2 * 10),
      channel: 0
    });
  });

  // Bass line
  const bassLine = [48, 50, 52, 53, 55, 57, 59, 60]; // C3 to C4
  bassLine.forEach((pitch, index) => {
    notes.push({
      pitch,
      startTime: 4.5 + (index * 0.4),
      duration: 0.35,
      velocity: 70,
      channel: 0
    });
  });

  return notes.sort((a, b) => a.startTime - b.startTime);
};

// Create data that tests different string positions
export const createStringTestData = (): NoteEvent[] => {
  const notes: NoteEvent[] = [];
  
  // Test different strings by using notes that will map to different strings
  const stringTestNotes = [
    { pitch: 40, time: 0 },    // E2 - 6th string open
    { pitch: 45, time: 0.5 },  // A2 - 5th string open
    { pitch: 50, time: 1.0 },  // D3 - 4th string open
    { pitch: 55, time: 1.5 },  // G3 - 3rd string open
    { pitch: 59, time: 2.0 },  // B3 - 2nd string open
    { pitch: 64, time: 2.5 },  // E4 - 1st string open
    { pitch: 65, time: 3.0 },  // F4 - 1st string 1st fret
    { pitch: 67, time: 3.5 },  // G4 - 1st string 3rd fret
    { pitch: 69, time: 4.0 },  // A4 - 1st string 5th fret
    { pitch: 71, time: 4.5 },  // B4 - 1st string 7th fret
    { pitch: 72, time: 5.0 },  // C5 - 1st string 8th fret
  ];

  stringTestNotes.forEach(({ pitch, time }) => {
    notes.push({
      pitch,
      startTime: time,
      duration: 0.4,
      velocity: 100,
      channel: 0
    });
  });

  return notes;
}; 