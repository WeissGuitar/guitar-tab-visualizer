'use client';

import React, { useMemo } from 'react';

interface NoteEvent {
  pitch: number;
  startTime: number;
  duration: number;
  velocity: number;
  stringIndex: number;
  fretNumber: number;
}

interface FretboardOverlayProps {
  currentTime: number;
  notes: NoteEvent[];
  width?: number;
  height?: number;
  showFingerNames?: boolean;
  showNoteNames?: boolean;
}

const FretboardOverlay: React.FC<FretboardOverlayProps> = ({
  currentTime,
  notes,
  width = 800,
  height = 200,
  showFingerNames = true,
  showNoteNames = false,
}) => {
  // Standard guitar tuning (low to high)
  const stringNames = ['E2', 'A2', 'D3', 'G3', 'B3', 'E4'];
  const stringColors = [
    'bg-red-500',    // Low E - Red
    'bg-orange-500', // A - Orange
    'bg-yellow-500', // D - Yellow
    'bg-green-500',  // G - Green
    'bg-blue-500',   // B - Blue
    'bg-purple-500', // High E - Purple
  ];

  // Fret positions (standard guitar fret spacing)
  const fretPositions = useMemo(() => {
    const positions: number[] = [0]; // Nut position
    let currentPos = 0;
    
    // Calculate fret positions using the rule of 18
    for (let i = 1; i <= 22; i++) {
      currentPos += (width - 60) / (Math.pow(2, i / 12) - 1);
      positions.push(currentPos);
    }
    
    return positions;
  }, [width]);

  // Fret marker positions (standard guitar markers)
  const fretMarkers = [3, 5, 7, 9, 12, 15, 17, 19, 21];

  // Find currently active notes
  const activeNotes = useMemo(() => {
    return notes.filter(note => 
      currentTime >= note.startTime && 
      currentTime <= note.startTime + note.duration
    );
  }, [notes, currentTime]);

  // Find upcoming notes (for anticipation)
  const upcomingNotes = useMemo(() => {
    return notes.filter(note => 
      note.startTime > currentTime && 
      note.startTime <= currentTime + 0.5 // Show 0.5s ahead
    );
  }, [notes, currentTime]);

  // Get finger position for a note
  const getFingerPosition = (stringIndex: number, fretNumber: number) => {
    const stringY = (height - 40) / 5 * stringIndex + 20; // 6 strings, 5 gaps
    const fretX = fretPositions[fretNumber] + 30; // 30px offset for string names
    
    return { x: fretX, y: stringY };
  };

  // Get finger color based on string
  const getFingerColor = (stringIndex: number, velocity: number) => {
    const baseColor = stringColors[stringIndex];
    const intensity = Math.min(velocity / 127, 1);
    const opacity = Math.max(60, Math.floor(intensity * 100));
    
    return `${baseColor} opacity-${opacity}`;
  };

  // Get finger name (for chord fingerings)
  const getFingerName = (stringIndex: number, fretNumber: number, activeNotes: NoteEvent[]) => {
    if (!showFingerNames) return '';
    
    // Simple finger assignment logic
    const sameTimeNotes = activeNotes.filter(note => 
      Math.abs(note.startTime - activeNotes[0].startTime) < 0.1
    );
    
    if (sameTimeNotes.length <= 1) return '';
    
    // Assign fingers based on position
    const sortedNotes = sameTimeNotes.sort((a, b) => a.stringIndex - b.stringIndex);
    const noteIndex = sortedNotes.findIndex(note => 
      note.stringIndex === stringIndex && note.fretNumber === fretNumber
    );
    
    const fingerNames = ['1', '2', '3', '4']; // Index, middle, ring, pinky
    return fingerNames[noteIndex] || '';
  };

  // Get note name
  const getNoteName = (pitch: number) => {
    const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const octave = Math.floor(pitch / 12) - 1;
    const noteName = noteNames[pitch % 12];
    return `${noteName}${octave}`;
  };

  return (
    <div className="w-full bg-guitar-primary rounded-lg overflow-hidden" style={{ height }}>
      {/* Header */}
      <div className="bg-guitar-secondary px-4 py-2 border-b border-gray-700">
        <div className="flex items-center justify-between">
          <h3 className="text-white font-semibold">Virtual Fretboard</h3>
          <div className="text-sm text-gray-400">
            Active Notes: {activeNotes.length} | Current Time: {currentTime.toFixed(2)}s
          </div>
        </div>
      </div>

      {/* Fretboard */}
      <div className="relative" style={{ height: height - 60 }}>
        {/* String names */}
        <div className="absolute left-0 top-0 w-8 h-full bg-guitar-secondary flex flex-col justify-around z-10">
          {stringNames.map((name, index) => (
            <div
              key={index}
              className="text-xs text-gray-300 font-mono text-center"
              style={{ 
                color: stringColors[index].replace('bg-', 'text-').replace('-500', '-300'),
                fontWeight: 'bold'
              }}
            >
              {name}
            </div>
          ))}
        </div>

        {/* Fretboard background */}
        <div 
          className="absolute left-8 right-0 top-0 bottom-0 bg-gradient-to-r from-amber-900 to-amber-800"
          style={{ backgroundImage: 'repeating-linear-gradient(90deg, transparent, transparent 1px, rgba(255,255,255,0.1) 1px, rgba(255,255,255,0.1) 2px)' }}
        />

        {/* Fret lines */}
        <svg
          className="absolute left-8 top-0 w-full h-full"
          style={{ width: width - 32 }}
        >
          {/* Vertical fret lines */}
          {fretPositions.map((position, index) => (
            <line
              key={index}
              x1={position}
              y1="0"
              x2={position}
              y2={height - 60}
              stroke={fretMarkers.includes(index) ? "#8B4513" : "#654321"}
              strokeWidth={fretMarkers.includes(index) ? "3" : "1"}
              opacity={fretMarkers.includes(index) ? 0.8 : 0.6}
            />
          ))}

          {/* Horizontal string lines */}
          {stringNames.map((_, index) => {
            const y = (height - 60) / 5 * index + 10;
            return (
              <line
                key={index}
                x1="0"
                y1={y}
                x2={width - 32}
                y2={y}
                stroke={stringColors[index].replace('bg-', '#').replace('-500', '')}
                strokeWidth="2"
                opacity="0.8"
              />
            );
          })}

          {/* Fret markers (dots) */}
          {fretMarkers.map(fretNum => {
            const x = fretPositions[fretNum];
            const centerY = (height - 60) / 2;
            
            return (
              <circle
                key={fretNum}
                cx={x}
                cy={centerY}
                r="8"
                fill="#8B4513"
                opacity="0.6"
              />
            );
          })}
        </svg>

        {/* Active finger overlays */}
        {activeNotes.map((note, index) => {
          const { x, y } = getFingerPosition(note.stringIndex, note.fretNumber);
          const fingerColor = getFingerColor(note.stringIndex, note.velocity);
          const fingerName = getFingerName(note.stringIndex, note.fretNumber, activeNotes);
          
          return (
            <div
              key={`active-${index}`}
              className={`absolute rounded-full flex items-center justify-center text-white font-bold shadow-lg animate-pulse-slow ${fingerColor}`}
              style={{
                left: x - 12,
                top: y - 12,
                width: 24,
                height: 24,
                zIndex: 20,
              }}
              title={`${getNoteName(note.pitch)} - String ${note.stringIndex + 1}, Fret ${note.fretNumber}`}
            >
              {fingerName}
            </div>
          );
        })}

        {/* Upcoming note indicators (subtle) */}
        {upcomingNotes.map((note, index) => {
          const { x, y } = getFingerPosition(note.stringIndex, note.fretNumber);
          
          return (
            <div
              key={`upcoming-${index}`}
              className="absolute rounded-full border-2 border-dashed border-gray-400 opacity-40"
              style={{
                left: x - 8,
                top: y - 8,
                width: 16,
                height: 16,
                zIndex: 15,
              }}
            />
          );
        })}

        {/* Note names overlay (optional) */}
        {showNoteNames && activeNotes.map((note, index) => {
          const { x, y } = getFingerPosition(note.stringIndex, note.fretNumber);
          
          return (
            <div
              key={`name-${index}`}
              className="absolute text-xs text-white bg-black bg-opacity-50 px-1 rounded"
              style={{
                left: x + 15,
                top: y - 10,
                zIndex: 25,
              }}
            >
              {getNoteName(note.pitch)}
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="bg-guitar-secondary px-4 py-2 border-t border-gray-700">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse" />
              <span>Active Note</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 border border-gray-400 border-dashed rounded-full opacity-40" />
              <span>Upcoming</span>
            </div>
          </div>
          <div className="text-right">
            <div>String Colors: E2(Red) A2(Orange) D3(Yellow) G3(Green) B3(Blue) E4(Purple)</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FretboardOverlay; 