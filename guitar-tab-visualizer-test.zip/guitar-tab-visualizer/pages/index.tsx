import React from 'react';

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-guitar-accent mb-4">
          GuitarTab Visualizer Pro
        </h1>
        <p className="text-gray-300 text-xl">
          🎸 Your guitar education tool is working!
        </p>
        <div className="mt-8">
          <a 
            href="/embed/default" 
            className="bg-guitar-accent text-white px-6 py-3 rounded-lg hover:bg-guitar-primary transition-colors"
          >
            View Embed Version
          </a>
        </div>
      </div>
    </div>
  );
} 