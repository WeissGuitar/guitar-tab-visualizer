'use client';

import React, { useState, useEffect, useRef } from 'react';
import VideoPlayer from './VideoPlayer';
import MidiXmlUploader from './MidiXmlUploader';
import TabRenderer from './TabRenderer';
import FretboardOverlay from './FretboardOverlay';

interface NoteEvent {
  pitch: number;
  startTime: number;
  duration: number;
  velocity: number;
  stringIndex: number;
  fretNumber: number;
}

interface EmbedWrapperProps {
  embedId?: string;
  compactOnly?: boolean;
  defaultExpanded?: boolean;
  videoSrc?: string;
  midiData?: NoteEvent[];
  theme?: 'dark' | 'light';
  showFooter?: boolean;
}

const EmbedWrapper: React.FC<EmbedWrapperProps> = ({
  embedId = 'default',
  compactOnly = false,
  defaultExpanded = false,
  videoSrc = '/test-video.mp4',
  midiData = [],
  theme = 'dark',
  showFooter = true,
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isLooping, setIsLooping] = useState(false);
  const [loopStart, setLoopStart] = useState(0);
  const [loopEnd, setLoopEnd] = useState(0);
  const [notes, setNotes] = useState<NoteEvent[]>(midiData);
  const [isLoading, setIsLoading] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Handle time updates from video player
  const handleTimeUpdate = (time: number) => {
    setCurrentTime(time);
  };

  const handleDurationChange = (dur: number) => {
    setDuration(dur);
    setLoopEnd(dur * 0.8);
  };

  const handleLoopToggle = (looping: boolean) => {
    setIsLooping(looping);
  };

  // Handle notes from MIDI uploader
  const handleNotesUpdate = (newNotes: NoteEvent[]) => {
    setNotes(newNotes);
  };

  // Toggle expanded view
  const toggleExpanded = () => {
    if (!compactOnly) {
      setIsExpanded(!isExpanded);
    }
  };

  // Auto-resize iframe if needed
  useEffect(() => {
    if (typeof window !== 'undefined' && window.parent !== window) {
      const resizeObserver = new ResizeObserver(() => {
        const height = containerRef.current?.scrollHeight || 400;
        window.parent.postMessage({
          type: 'resize',
          height: height + 20, // Add padding
          embedId
        }, '*');
      });

      if (containerRef.current) {
        resizeObserver.observe(containerRef.current);
      }

      return () => resizeObserver.disconnect();
    }
  }, [isExpanded, notes, embedId]);

  // Theme classes
  const themeClasses = {
    dark: {
      container: 'bg-gray-900 text-white',
      card: 'bg-guitar-primary border-gray-700',
      button: 'bg-guitar-accent hover:bg-orange-500 text-white',
      secondary: 'bg-guitar-secondary text-gray-300',
    },
    light: {
      container: 'bg-gray-50 text-gray-900',
      card: 'bg-white border-gray-200 shadow-lg',
      button: 'bg-blue-600 hover:bg-blue-700 text-white',
      secondary: 'bg-gray-100 text-gray-700',
    },
  };

  const currentTheme = themeClasses[theme];

  return (
    <div 
      ref={containerRef}
      className={`min-h-screen ${currentTheme.container} transition-all duration-300`}
    >
      {/* Header */}
      <div className={`${currentTheme.card} border-b p-4`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl">🎸</div>
            <div>
              <h1 className="text-lg font-bold">GuitarTab Visualizer Pro</h1>
              <p className="text-sm opacity-70">Interactive guitar learning tool</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {!compactOnly && (
              <button
                onClick={toggleExpanded}
                className={`px-4 py-2 rounded-lg transition-colors text-sm font-medium ${currentTheme.button}`}
              >
                {isExpanded ? 'Collapse' : 'Expand'}
              </button>
            )}
            
            {theme === 'dark' && (
              <button
                onClick={() => window.location.href = `?theme=light&embedId=${embedId}`}
                className="p-2 rounded-lg bg-gray-700 hover:bg-gray-600 transition-colors"
                title="Switch to light theme"
              >
                ☀️
              </button>
            )}
            
            {theme === 'light' && (
              <button
                onClick={() => window.location.href = `?theme=dark&embedId=${embedId}`}
                className="p-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition-colors"
                title="Switch to dark theme"
              >
                🌙
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-4">
        {/* Compact Mode */}
        {!isExpanded && (
          <div className="space-y-4">
            {/* Video Player (Compact) */}
            <div className={`${currentTheme.card} rounded-lg overflow-hidden`}>
              <VideoPlayer
                src={videoSrc}
                onTimeUpdate={handleTimeUpdate}
                onDurationChange={handleDurationChange}
                loopStart={loopStart}
                loopEnd={loopEnd}
                isLooping={isLooping}
                onLoopToggle={handleLoopToggle}
              />
            </div>

            {/* Tab Renderer (Compact) */}
            {notes.length > 0 && (
              <div className={`${currentTheme.card} rounded-lg overflow-hidden`}>
                <TabRenderer
                  notes={notes}
                  currentTime={currentTime}
                  width={800}
                  height={250}
                  showNoteNames={false}
                  colorByPitch={true}
                />
              </div>
            )}

            {/* MIDI Uploader (Compact) */}
            {notes.length === 0 && (
              <div className={`${currentTheme.card} rounded-lg p-6`}>
                <div className="text-center">
                  <div className="text-4xl mb-4">🎵</div>
                  <h3 className="text-lg font-semibold mb-2">Upload MIDI File</h3>
                  <p className="text-sm opacity-70 mb-4">
                    Drag and drop a MIDI file to see the guitar tab visualization
                  </p>
                  <MidiXmlUploader />
                </div>
              </div>
            )}
          </div>
        )}

        {/* Expanded Mode */}
        {isExpanded && (
          <div className="space-y-6">
            {/* Top Row: Video + Fretboard */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Video Player */}
              <div className={`${currentTheme.card} rounded-lg overflow-hidden`}>
                <VideoPlayer
                  src={videoSrc}
                  onTimeUpdate={handleTimeUpdate}
                  onDurationChange={handleDurationChange}
                  loopStart={loopStart}
                  loopEnd={loopEnd}
                  isLooping={isLooping}
                  onLoopToggle={handleLoopToggle}
                />
              </div>

              {/* Fretboard Overlay */}
              {notes.length > 0 && (
                <div className={`${currentTheme.card} rounded-lg overflow-hidden`}>
                  <FretboardOverlay
                    notes={notes}
                    currentTime={currentTime}
                    width={400}
                    height={300}
                    showFingerNames={true}
                    showNoteNames={false}
                  />
                </div>
              )}
            </div>

            {/* Bottom Row: Tab Renderer + MIDI Uploader */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Tab Renderer */}
              {notes.length > 0 && (
                <div className="lg:col-span-2">
                  <div className={`${currentTheme.card} rounded-lg overflow-hidden`}>
                    <TabRenderer
                      notes={notes}
                      currentTime={currentTime}
                      width={600}
                      height={300}
                      showNoteNames={true}
                      colorByPitch={true}
                    />
                  </div>
                </div>
              )}

              {/* MIDI Uploader */}
              <div className={`${currentTheme.card} rounded-lg p-4`}>
                <h3 className="text-lg font-semibold mb-4">MIDI Upload</h3>
                <MidiXmlUploader />
              </div>
            </div>

            {/* Loop Controls */}
            <div className={`${currentTheme.card} rounded-lg p-4`}>
              <h3 className="text-lg font-semibold mb-4">Loop Controls</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Loop Start (seconds)</label>
                  <input
                    type="number"
                    value={loopStart}
                    onChange={(e) => setLoopStart(parseFloat(e.target.value) || 0)}
                    className={`w-full px-3 py-2 rounded-lg border ${currentTheme.secondary}`}
                    min="0"
                    max={duration}
                    step="0.1"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Loop End (seconds)</label>
                  <input
                    type="number"
                    value={loopEnd}
                    onChange={(e) => setLoopEnd(parseFloat(e.target.value) || 0)}
                    className={`w-full px-3 py-2 rounded-lg border ${currentTheme.secondary}`}
                    min="0"
                    max={duration}
                    step="0.1"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      {showFooter && (
        <div className={`${currentTheme.card} border-t p-4 mt-8`}>
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center space-x-2">
              <span>Powered by</span>
              <span className="font-semibold text-guitar-accent">GuitarTab Visualizer Pro</span>
            </div>
            <div className="text-xs opacity-60">
              Embed ID: {embedId}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EmbedWrapper; 