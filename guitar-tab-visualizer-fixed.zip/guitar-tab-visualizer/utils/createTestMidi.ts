// Utility to create a simple test MIDI file
// This is for development/testing purposes only

export const createTestMidiData = () => {
  // Simple MIDI data structure for testing
  const testMidiData = {
    notes: [
      { pitch: 60, startTime: 0, duration: 0.5, velocity: 100, channel: 0 }, // C4
      { pitch: 62, startTime: 0.5, duration: 0.5, velocity: 100, channel: 0 }, // D4
      { pitch: 64, startTime: 1.0, duration: 0.5, velocity: 100, channel: 0 }, // E4
      { pitch: 65, startTime: 1.5, duration: 0.5, velocity: 100, channel: 0 }, // F4
      { pitch: 67, startTime: 2.0, duration: 1.0, velocity: 100, channel: 0 }, // G4
      { pitch: 69, startTime: 3.0, duration: 0.5, velocity: 100, channel: 0 }, // A4
      { pitch: 71, startTime: 3.5, duration: 0.5, velocity: 100, channel: 0 }, // B4
      { pitch: 72, startTime: 4.0, duration: 1.0, velocity: 100, channel: 0 }, // C5
    ],
    duration: 5.0,
    tempo: 120,
    timeSignature: [4, 4] as [number, number]
  };

  return testMidiData;
};

// Function to create a downloadable test MIDI file
export const downloadTestMidi = () => {
  // This would create an actual MIDI file
  // For now, we'll just log the test data
  console.log('Test MIDI Data:', createTestMidiData());
  
  // In a real implementation, you would:
  // 1. Convert the data to MIDI format
  // 2. Create a Blob
  // 3. Create a download link
  // 4. Trigger download
  
  alert('Test MIDI data logged to console. In a real implementation, this would download a .mid file.');
}; 